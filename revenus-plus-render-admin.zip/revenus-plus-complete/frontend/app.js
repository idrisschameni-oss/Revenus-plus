const API_BASE = localStorage.getItem("revenus_api") || (location.hostname.endsWith("onrender.com") ? "https://revenus-plus-api.onrender.com" : "");
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const tokenKey = "revenus_token";
const userKey = "revenus_user";

$("#apiLabel").textContent = API_BASE;

function token(){ return localStorage.getItem(tokenKey); }
function user(){ try{return JSON.parse(localStorage.getItem(userKey)||"null")}catch{return null} }
function money(v){ return Number(v||0).toLocaleString("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2}); }
function dateFR(v){ if(!v)return "—"; return new Date(v+"T00:00:00").toLocaleDateString("fr-FR"); }
function showToast(msg,error=false){const t=$("#toast");t.textContent=msg;t.className="toast show"+(error?" error":"");setTimeout(()=>t.className="toast",3000)}
function initials(name){return (name||"U").slice(0,1).toUpperCase()}

async function api(path, options={}){
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(token()) headers.Authorization=`Bearer ${token()}`;
  const res=await fetch(API_BASE+path,{...options,headers});
  let data=null; try{data=await res.json()}catch{}
  if(!res.ok){
    if(res.status===401){logout(false); throw new Error("Session expirée. Reconnectez-vous.")}
    throw new Error(data?.detail || `Erreur ${res.status}`);
  }
  return data;
}
function saveSession(data){localStorage.setItem(tokenKey,data.access_token);localStorage.setItem(userKey,JSON.stringify(data.user));enterApp(data.user)}
async function checkAdmin(){
  try{ const r=await api("/api/admin/me"); $("#adminNav").classList.toggle("hidden", !r.is_admin); return r.is_admin; }catch{return false}
}

function enterApp(u){
  $("#authView").classList.add("hidden");$("#appView").classList.remove("hidden");
  $("#sideName").textContent=u.prenom;$("#sideEmail").textContent=u.email;$("#topName").textContent=u.prenom;
  $("#welcomeName").textContent=u.prenom;$("#avatar").textContent=initials(u.prenom);$("#topAvatar").textContent=initials(u.prenom);
  loadDashboard();
  checkAdmin();
}
function logout(show=true){localStorage.removeItem(tokenKey);localStorage.removeItem(userKey);$("#appView").classList.add("hidden");$("#authView").classList.remove("hidden");if(show)showToast("Vous êtes déconnecté.");}

$$(".tab").forEach(btn=>btn.addEventListener("click",()=>{$$(".tab").forEach(x=>x.classList.remove("active"));btn.classList.add("active");const login=btn.dataset.auth==="login";$("#loginForm").classList.toggle("hidden",!login);$("#registerForm").classList.toggle("hidden",login)}));
$("#loginForm").addEventListener("submit",async e=>{e.preventDefault();try{saveSession(await api("/api/auth/login",{method:"POST",body:JSON.stringify({email:$("#loginEmail").value,password:$("#loginPassword").value})}));showToast("Connexion réussie.");}catch(err){showToast(err.message,true)}});
$("#registerForm").addEventListener("submit",async e=>{e.preventDefault();try{const body={prenom:$("#registerPrenom").value,email:$("#registerEmail").value,password:$("#registerPassword").value};if($("#registerReferral").value.trim())body.referral_code=$("#registerReferral").value.trim();saveSession(await api("/api/auth/register",{method:"POST",body:JSON.stringify(body)}));showToast("Compte créé avec succès.");}catch(err){showToast(err.message,true)}});

const titles={dashboard:"Tableau de bord",salary:"Revenus / salaire",expenses:"Dépenses & budget",simulators:"Simulateurs",referral:"Parrainage",admin:"Administration"};
function goPage(page){$$(".page").forEach(p=>p.classList.add("hidden"));$(`#page-${page}`).classList.remove("hidden");$$(".nav-item").forEach(n=>n.classList.toggle("active",n.dataset.page===page));$("#pageTitle").textContent=titles[page];$("#sidebar").classList.remove("open");if(page==="dashboard")loadDashboard();if(page==="salary")loadSalary();if(page==="expenses")loadExpenses();if(page==="referral")loadReferral();if(page==="admin")loadAdmin();}
$$(".nav-item").forEach(n=>n.addEventListener("click",()=>goPage(n.dataset.page)));
$$("[data-page-go]").forEach(n=>n.addEventListener("click",()=>goPage(n.dataset.pageGo)));
$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#logoutBtn").addEventListener("click",()=>logout());

async function loadDashboard(){
  try{
    const [s,e]=await Promise.all([api("/api/salary/summary"),api("/api/expenses/summary")]);
    $("#dashNet").textContent=money(s.total_net);$("#dashGross").textContent=money(s.total_brut);$("#dashExpenses").textContent=money(e.total_general);$("#dashBalance").textContent=money(s.total_net-e.total_general);
    const [weeks,items]=await Promise.all([api("/api/salary/weeks"),api("/api/expenses/items")]);
    $("#recentSalary").innerHTML=weeks.length?weeks.slice(-5).reverse().map(w=>`<div class="list-row"><div><strong>${dateFR(w.date)}</strong><small>${w.devise} · brut ${money(w.brut)}</small></div><span class="amount positive">+${money(w.net)}</span></div>`).join(""):`<div class="empty">Aucun revenu enregistré.</div>`;
    $("#recentExpenses").innerHTML=items.length?items.slice(-5).reverse().map(x=>`<div class="list-row"><div><strong>${escapeHtml(x.categorie)}</strong><small>${dateFR(x.date)}</small></div><span class="amount negative">−${money(x.montant)}</span></div>`).join(""):`<div class="empty">Aucune dépense enregistrée.</div>`;
  }catch(err){showToast(err.message,true)}
}
async function loadSalary(){
  try{
    const [s,weeks]=await Promise.all([api("/api/salary/summary"),api("/api/salary/weeks")]);
    $("#salaryWeeks").textContent=s.nb_semaines;$("#salaryGross").textContent=money(s.total_brut);$("#salaryCharges").textContent=money(s.total_charges);$("#salaryNet").textContent=money(s.total_net);
    $("#salaryTable").innerHTML=weeks.length?`<table class="data-table"><thead><tr><th>Date</th><th>Brut</th><th>Charges</th><th>Net</th><th></th></tr></thead><tbody>${weeks.slice().reverse().map(w=>`<tr><td>${dateFR(w.date)}</td><td>${money(w.brut)} ${w.devise}</td><td>${money(w.charges)}</td><td><b>${money(w.net)}</b></td><td><button class="delete-btn" onclick="deleteSalary(${w.id})">Supprimer</button></td></tr>`).join("")}</tbody></table>`:`<div class="empty">Aucune semaine enregistrée.</div>`;
  }catch(err){showToast(err.message,true)}
}
$("#salaryForm").addEventListener("submit",async e=>{
  e.preventDefault();
  try{
    const gross=$("#salaryGrossInput").value.trim();const hours=$("#salaryHours").value.trim();const rate=$("#hourRate").value.trim();
    if(!gross && !(hours&&rate)) throw new Error("Saisissez le salaire brut ou les heures et le taux horaire.");
    const body={date:$("#salaryDate").value,taux_cotisations:Number($("#contrib").value||0),taux_impot:Number($("#tax").value||0),autres_retenues:Number($("#otherDeduct").value||0),devise:$("#salaryCurrency").value};
    if(gross)body.salaire_brut=Number(gross);else{body.heures=Number(hours);body.taux_horaire=Number(rate)}
    await api("/api/salary/weeks",{method:"POST",body:JSON.stringify(body)});showToast("Revenu enregistré.");e.target.reset();$("#salaryDate").valueAsDate=new Date();loadSalary();
  }catch(err){showToast(err.message,true)}
});
window.deleteSalary=async id=>{if(!confirm("Supprimer cette semaine ?"))return;try{await api(`/api/salary/weeks/${id}`,{method:"DELETE"});showToast("Semaine supprimée.");loadSalary()}catch(err){showToast(err.message,true)}};

async function loadExpenses(){
  try{
    const [summary,cats,items]=await Promise.all([api("/api/expenses/summary"),api("/api/expenses/categories"),api("/api/expenses/items")]);
    const sel=$("#expenseCategory");sel.innerHTML=cats.length?cats.map(c=>`<option value="${escapeAttr(c.nom)}">${escapeHtml(c.nom)}</option>`).join(""):`<option value="">Créez d’abord une catégorie</option>`;
    $("#expenseTotal").textContent=money(summary.total_general);
    $("#budgetSummary").innerHTML=cats.length?cats.map(c=>{const total=summary.total_par_categorie?.[c.nom]||0;const pct=c.plafond?Math.min(total/c.plafond*100,100):0;const over=summary.depassements?.[c.nom];return `<div class="budget-row"><div class="budget-row-head"><span>${escapeHtml(c.nom)}</span><span>${money(total)}${c.plafond!==null?` / ${money(c.plafond)}`:""}</span></div>${c.plafond!==null?`<div class="bar"><i class="${over?"over":""}" style="width:${pct}%"></i></div>`:""}${over?`<small class="negative">Dépassement : ${money(over)}</small>`:""}</div>`}).join(""):`<div class="empty">Aucune catégorie.</div>`;
    $("#expenseTable").innerHTML=items.length?`<table class="data-table"><thead><tr><th>Date</th><th>Catégorie</th><th>Montant</th><th>Description</th><th></th></tr></thead><tbody>${items.slice().reverse().map(x=>`<tr><td>${dateFR(x.date)}</td><td>${escapeHtml(x.categorie)}</td><td><b>${money(x.montant)}</b></td><td>${escapeHtml(x.description||"—")}</td><td><button class="delete-btn" onclick="deleteExpense(${x.id})">Supprimer</button></td></tr>`).join("")}</tbody></table>`:`<div class="empty">Aucune dépense.</div>`;
  }catch(err){showToast(err.message,true)}
}
$("#categoryForm").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/expenses/categories",{method:"POST",body:JSON.stringify({nom:$("#categoryName").value,plafond:$("#categoryLimit").value?Number($("#categoryLimit").value):null})});showToast("Catégorie créée.");e.target.reset();loadExpenses()}catch(err){showToast(err.message,true)}});
$("#expenseForm").addEventListener("submit",async e=>{e.preventDefault();try{if(!$("#expenseCategory").value)throw new Error("Créez une catégorie avant d’ajouter une dépense.");await api("/api/expenses/items",{method:"POST",body:JSON.stringify({categorie:$("#expenseCategory").value,montant:Number($("#expenseAmount").value),date:$("#expenseDate").value,description:$("#expenseDescription").value||null})});showToast("Dépense ajoutée.");e.target.reset();$("#expenseDate").valueAsDate=new Date();loadExpenses()}catch(err){showToast(err.message,true)}});
window.deleteExpense=async id=>{if(!confirm("Supprimer cette dépense ?"))return;try{await api(`/api/expenses/${id}`,{method:"DELETE"});showToast("Dépense supprimée.");loadExpenses()}catch(err){showToast(err.message,true)}};

$("#feeForm").addEventListener("submit",async e=>{e.preventDefault();try{const body={montant:Number($("#feeAmount").value),frais_fixe:Number($("#feeFixed").value||0),taux_pourcentage:Number($("#feePct").value||0)};if($("#feeMin").value)body.frais_min=Number($("#feeMin").value);if($("#feeMax").value)body.frais_max=Number($("#feeMax").value);const r=await api("/api/transactions/fee",{method:"POST",body:JSON.stringify(body)});$("#feeResult").classList.remove("hidden");$("#feeResult").innerHTML=`<span>Montant final</span><strong>${money(r.montant_final)}</strong><div class="result-grid"><span>Frais fixe</span><b>${money(r.frais_fixe)}</b><span>Frais %</span><b>${money(r.frais_pourcentage)}</b><span>Total frais</span><b>${money(r.frais_total)}</b></div>`}catch(err){showToast(err.message,true)}});
$("#convertForm").addEventListener("submit",async e=>{e.preventDefault();try{const r=await api("/api/transactions/convert",{method:"POST",body:JSON.stringify({montant:Number($("#convertAmount").value),taux_change:Number($("#exchangeRate").value),frais_conversion_pct:Number($("#convertFee").value||0)})});$("#convertResult").classList.remove("hidden");$("#convertResult").innerHTML=`<span>Montant converti final</span><strong>${money(r.montant_final)}</strong><div class="result-grid"><span>Brut converti</span><b>${money(r.montant_converti_brut)}</b><span>Frais</span><b>${money(r.frais_conversion)}</b><span>Taux</span><b>${r.taux_change}</b></div>`}catch(err){showToast(err.message,true)}});

async function loadReferral(){try{const r=await api("/api/referral/me");$("#refCode").textContent=r.referral_code;$("#refCount").textContent=`${r.filleuls_count} filleul${r.filleuls_count>1?"s":""}`;$("#refLink").value=r.referral_link}catch(err){showToast(err.message,true)}}
$("#copyRef").addEventListener("click",async()=>{try{await navigator.clipboard.writeText($("#refLink").value);showToast("Lien copié.")}catch{showToast("Copie impossible sur ce navigateur.",true)}});

async function loadAdmin(){
  try{
    const [o,users,activities]=await Promise.all([api("/api/admin/overview"),api("/api/admin/users"),api("/api/admin/activities?limit=80")]);
    $("#adminUsers").textContent=o.user_count;$("#adminSalaryCount").textContent=o.salary_count;$("#adminExpenseCount").textContent=o.expense_count;$("#adminActivityCount").textContent=o.activity_count;
    $("#adminSalaryTotal").textContent=money(o.salary_total);$("#adminExpenseTotal").textContent=money(o.expense_total);
    $("#adminUserTable").innerHTML=users.length?`<table class="data-table"><thead><tr><th>Utilisateur</th><th>Email</th><th>Inscrit</th><th></th></tr></thead><tbody>${users.map(u=>`<tr><td><b>${escapeHtml(u.prenom)}</b></td><td>${escapeHtml(u.email)}</td><td>${new Date(u.created_at).toLocaleDateString("fr-FR")}</td><td>${u.id===user().id?"<small>Administrateur</small>":`<button class="delete-btn" onclick="adminDeleteUser(${u.id})">Supprimer</button>`}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Aucun utilisateur.</div>`;
    $("#adminActivityTable").innerHTML=activities.length?`<table class="data-table"><thead><tr><th>Date</th><th>ID utilisateur</th><th>Méthode</th><th>Route</th><th>Statut</th></tr></thead><tbody>${activities.map(a=>`<tr><td>${new Date(a.created_at).toLocaleString("fr-FR")}</td><td>${a.user_id??"—"}</td><td><b>${a.method}</b></td><td>${escapeHtml(a.path)}</td><td>${a.status_code}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Aucune activité.</div>`;
  }catch(err){showToast(err.message,true)}
}
window.adminDeleteUser=async id=>{if(!confirm("Supprimer définitivement ce compte et toutes ses données ?"))return;try{await api(`/api/admin/users/${id}`,{method:"DELETE"});showToast("Compte supprimé.");loadAdmin()}catch(err){showToast(err.message,true)}};
$("#refreshAdmin").addEventListener("click",loadAdmin);

function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function escapeAttr(v){return escapeHtml(v).replace(/`/g,"&#096;")}

(async function init(){
  $("#salaryDate").valueAsDate=new Date();$("#expenseDate").valueAsDate=new Date();
  const ref=new URLSearchParams(location.search).get("ref");
  if(ref){ $("#registerReferral").value=ref.toUpperCase(); $$(".tab").forEach(x=>x.classList.remove("active")); $$(".tab").find(x=>x.dataset.auth==="register")?.classList.add("active"); $("#loginForm").classList.add("hidden"); $("#registerForm").classList.remove("hidden"); }
  if(token()){try{const u=await api("/api/auth/me");localStorage.setItem(userKey,JSON.stringify(u));enterApp(u)}catch{logout(false)}}
})();
