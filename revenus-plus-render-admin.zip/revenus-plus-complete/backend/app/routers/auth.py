import random
import string

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import models, schemas, security
from ..auth import get_current_user
from ..database import get_db

router = APIRouter(prefix="/api/auth", tags=["auth"])


def generate_referral_code(prenom: str, db: Session) -> str:
    """Génère un code de parrainage unique à partir du prénom (ex: AWA482)."""
    base = "".join(ch for ch in prenom.upper() if ch.isalpha())[:4] or "USER"
    while True:
        code = base + "".join(random.choices(string.digits, k=3))
        if not db.query(models.User).filter(models.User.referral_code == code).first():
            return code


@router.post("/register", response_model=schemas.Token, status_code=status.HTTP_201_CREATED)
def register(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Un compte existe déjà avec cet email.")

    referred_by = None
    if payload.referral_code:
        parrain = (
            db.query(models.User)
            .filter(models.User.referral_code == payload.referral_code.upper())
            .first()
        )
        if not parrain:
            raise HTTPException(status_code=400, detail="Ce code de parrainage est introuvable.")
        referred_by = parrain.referral_code

    user = models.User(
        prenom=payload.prenom,
        email=payload.email,
        hashed_password=security.hash_password(payload.password),
        referral_code=generate_referral_code(payload.prenom, db),
        referred_by=referred_by,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    token = security.create_access_token({"sub": str(user.id)})
    return schemas.Token(access_token=token, user=schemas.UserOut.model_validate(user))


@router.post("/login", response_model=schemas.Token)
def login(payload: schemas.UserLogin, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == payload.email).first()
    if not user or not security.verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect.")

    token = security.create_access_token({"sub": str(user.id)})
    return schemas.Token(access_token=token, user=schemas.UserOut.model_validate(user))


@router.get("/me", response_model=schemas.UserOut)
def me(current_user: models.User = Depends(get_current_user)):
    return current_user
